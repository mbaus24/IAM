function z = rosenbrock(x, y)
z = 100 * (y - x.^2).^2 + (1 - x).^2;