function y = forme_quad(x)
y = x.^2;